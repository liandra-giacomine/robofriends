import React from 'react'

const RobotProfile = () => {
    return (
      <div>
        <h1>Hello World</h1>
      </div>
    );
  }
  
  export default RobotProfile;
